<?php
	$dbServerName="localhost";
	$dbUserName="root";
	$dbPassword="";
	$dbName="hostel_mng";
	$conn=mysqli_connect('localhost','root','','hostel_mng');
?>
